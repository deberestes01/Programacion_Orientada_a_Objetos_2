﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExamenRosaNavarrete
{
    public partial class pag02 : System.Web.UI.Page
    {
        public String strNickName, strAvatar;

        

        protected void ddlMarca_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlMarca.SelectedIndex == 0)
                SqlDataSourceGridView.FilterExpression = null;
            else
                SqlDataSourceGridView.FilterExpression = "co_mar={0}";
        }

        public void count()
        {
            lblCount.Text = "Contador: " + GridView1.Rows.Count.ToString();
        }

        protected void GridView1_DataBound(object sender, EventArgs e)
        {
            count();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                strNickName = Request.Form.GetValues("txtName")[0];
            }
            catch (Exception exc)
            {
                strNickName = " ";
            }

            try
            {
                strAvatar = Request.Form.GetValues("ddlAvatar")[0];
            }
            catch (Exception exc)
            {
                strAvatar = " ";
            }
        }
    }
}