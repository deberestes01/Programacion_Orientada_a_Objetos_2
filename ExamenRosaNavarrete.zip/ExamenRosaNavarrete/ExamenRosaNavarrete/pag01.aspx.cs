﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ExamenRosaNavarrete
{
    public partial class pag01 : System.Web.UI.Page
    {
        public string strNickName, strAvatar;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                strNickName = Request.QueryString.GetValues("v1")[0];
            }
            catch (Exception exc)
            {
                strNickName = "";
            }

            try
            {
                strAvatar = Request.QueryString.GetValues("v2")[0];
            }
            catch (Exception exc)
            {
                strAvatar = "";
            }
            txtName.Text = strNickName;
            ddlAvatar.SelectedValue = strAvatar;
        }

        protected void bnAce_Click(object sender, EventArgs e)
        {

        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string intValue = args.Value;
            int palabra = intValue.Length;
            if (palabra >= 5)
                args.IsValid = true;
            else
                args.IsValid = false;
        }
    }
}